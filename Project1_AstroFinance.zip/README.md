# ml-project1
First project of the ML course at EPFL Autumn 2019
